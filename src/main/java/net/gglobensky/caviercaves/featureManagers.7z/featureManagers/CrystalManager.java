package net.gglobensky.caviercaves.featureManagers;

import net.gglobensky.caviercaves.init.CaviercavesModBlocks;
import net.gglobensky.caviercaves.procedures.Utils;
import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.LevelAccessor;

import java.util.Random;

public class CrystalManager {
    enum CrystalOrientation {
        UP,
        DOWN,
        EAST,
        WEST,
        NORTH,
        SOUTH
    }

    private static int[][] orientations = { {0, 1}, {0, -1}, {1, 0}, {-1, 0} };

    public static void createCrystals(LevelAccessor world, double x, double y, double z) {
        int minHeight = 2;
        int maxHeight = 12;
        int thickness = 1;
        int maxNumberOfBentSections = 4;
        float bendingChance = 0.25f;

        createCrystal(world, x, y, z, minHeight, maxHeight, thickness, maxNumberOfBentSections, bendingChance, CrystalOrientation.UP);
        createCrystal(world, x, y, z, minHeight, maxHeight, thickness, maxNumberOfBentSections, bendingChance, CrystalOrientation.DOWN);
        createCrystal(world, x, y, z, minHeight, maxHeight, thickness, maxNumberOfBentSections, bendingChance, CrystalOrientation.EAST);
        createCrystal(world, x, y, z, minHeight, maxHeight, thickness, maxNumberOfBentSections, bendingChance, CrystalOrientation.WEST);
        createCrystal(world, x, y, z, minHeight, maxHeight, thickness, maxNumberOfBentSections, bendingChance, CrystalOrientation.NORTH);
        createCrystal(world, x, y, z, minHeight, maxHeight, thickness, maxNumberOfBentSections, bendingChance, CrystalOrientation.SOUTH);
    }

    private static void createCrystal(LevelAccessor world, double x, double y, double z, int minHeight, int maxHeight, int thickness, int maxNumberOfBentSections, float bendingChance, CrystalOrientation crystalOrientation){
        int height = Utils.RandomRange(minHeight, maxHeight);
        int orientationIndex = (int) (Math.random() * orientations.length);
        int[] currentOrientation = {0, 0};

        if (Math.random() <= bendingChance){
            int sections = (int) (Math.random() * maxNumberOfBentSections) + 1;
            int snappingInterval = (int) (height / sections);
            int intervalCounter = 0;

            for (int i = 0; i < height; i++){
                for (int wOffset = 0; wOffset < thickness; wOffset++){
                    for (int lOffset = 0; lOffset < thickness; lOffset++){
                        BlockPos pos = getOffsetPosition(wOffset, lOffset, x, y, z, crystalOrientation);
                        pos = getOrientedBlockPos(pos.getX(), pos.getY(), pos.getZ(), currentOrientation, crystalOrientation);
                        int[] increment = getIncrement(i, crystalOrientation);

                        world.setBlock(new BlockPos(pos.getX() + increment[0], pos.getY() + increment[1], pos.getZ() + increment[2]), CaviercavesModBlocks.GHOST_FUNGUS_STEM.get().defaultBlockState(), 3);
                    }
                }

                if (intervalCounter++ >= snappingInterval){
                    intervalCounter = 0;
                    currentOrientation[0] += orientations[orientationIndex][0];
                    currentOrientation[1] += orientations[orientationIndex][1];

                    for (int wOffset = 0; wOffset < thickness; wOffset++){
                        for (int lOffset = 0; lOffset < thickness; lOffset++){
                            BlockPos pos = getOffsetPosition(wOffset, lOffset, x, y, z, crystalOrientation);
                            pos = getOrientedBlockPos(pos.getX(), pos.getY(), pos.getZ(), currentOrientation, crystalOrientation);
                            int[] increment = getIncrement(i, crystalOrientation);

                            world.setBlock(new BlockPos(pos.getX() + increment[0], pos.getY() + increment[1], pos.getZ() + increment[2]), CaviercavesModBlocks.GHOST_FUNGUS_STEM.get().defaultBlockState(), 3);
                        }
                    }
                }
            }
        }
        else{
            for (int i = 0; i < height; i++){
                for (int wOffset = 0; wOffset < thickness; wOffset++){
                    for (int lOffset = 0; lOffset < thickness; lOffset++){
                        BlockPos pos = getOffsetPosition(wOffset, lOffset, x, y, z, crystalOrientation);
                        int[] increment = getIncrement(i, crystalOrientation);

                        world.setBlock(new BlockPos(pos.getX() + increment[0], pos.getY() + increment[1], pos.getZ() + increment[2]), CaviercavesModBlocks.GHOST_FUNGUS_STEM.get().defaultBlockState(), 3);
                    }
                }
            }
        }
    }

    //Takes in x y z values for an upright elements and outputs the orientated coordinates
    private static int[] getIncrement(int currentValue, CrystalOrientation crystalOrientation){
        switch(crystalOrientation) {
            case UP:
                return new int[] {0, currentValue, 0};
            case DOWN:
                return new int[] {0, -currentValue, 0};
            case WEST:
                return new int[] {-currentValue, 0, 0};
            case EAST:
                return new int[] {currentValue, 0, 0};
            case NORTH:
                return new int[] {0, 0, currentValue};
            case SOUTH:
                return new int[] {0, 0, -currentValue};
            default:
                return new int[] {0, 0, 0};
        }
    }

    private static BlockPos getOffsetPosition(int wOffset, int lOffset, double x, double y, double z, CrystalOrientation crystalOrientation){
        switch(crystalOrientation) {
            case UP, DOWN:
                return new BlockPos(x + wOffset, y, z + lOffset);
            case WEST, EAST:
                return new BlockPos(x, y + wOffset, z + lOffset);
            case NORTH, SOUTH:
                return new BlockPos(x + wOffset, y + lOffset, z);
            default:
                return new BlockPos(x, y, z);
        }
    }

    private static BlockPos getOrientedBlockPos(double x, double y, double z, int[] orientation, CrystalOrientation crystalOrientation){
        switch(crystalOrientation) {
            case UP:
                return new BlockPos(x + orientation[0], y, z + orientation[1]);
            case DOWN:
                return new BlockPos(x - orientation[0], y, z - orientation[1]);
            case WEST:
                return new BlockPos(x, y + orientation[0], z + orientation[1]);
            case EAST:
                return new BlockPos(x, y - orientation[0], z - orientation[1]);
            case NORTH:
                return new BlockPos(x + orientation[0], y + orientation[1], z);
            case SOUTH:
                return new BlockPos(x - orientation[0], y - orientation[1], z);
            default:
                return new BlockPos(x, y, z);
        }
    }

}
